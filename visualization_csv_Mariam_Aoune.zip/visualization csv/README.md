# masculinity survey data visualization

The programs displays the data in text form and visually through circles and lines. 

The number of lines in circles depends on the scale of the percentage. For example, a circle representing the result of 85 will show more lines than a circle representing 15%. 

The font used was intended to make the subject feel intimate and personal as if someone is writing in a journal. 

## Difficulties encountered
1. I found it difficult to retrieve the answers 
2. It was also challenging to display each question consecutively after the button click. The use of many booleans was necessary.
3. Identifying the empty string was necessary but difficult to establish. 

A mood board helped me gain a visual idea regarding the appearance of the code. 

![image](https://user-images.githubusercontent.com/53101129/223040182-1345bf9e-775a-455a-b403-2128051a3d69.png)

Overall, the program has reached my expectations and represents my intended visuals. 
